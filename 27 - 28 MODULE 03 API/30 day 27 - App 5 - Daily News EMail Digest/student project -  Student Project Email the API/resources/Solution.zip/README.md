# What is this project?
This app accesses news about a particular topic and sends them by email.